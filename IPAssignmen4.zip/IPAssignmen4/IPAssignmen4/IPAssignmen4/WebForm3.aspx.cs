﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Reflection;

public partial class WebForm3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string username = (string)Session["UserName"];
        Label1.Text = username;
        

    }


    protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void btnFriend_Click(object sender, EventArgs e)
    {
        Session["Friend"] = txtFriend.Text;
       
        txtFriendComment.Visible = true;
        btnComment.Visible = true;
        DataList2.Visible = true;
    }

    protected void btnComment_Click(object sender, EventArgs e)
    {

        string friend = (string)Session["Friend"];
        try
        {

            string constring = ConfigurationManager.ConnectionStrings["IPProjectConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO Comments (Comment_Sender, Comment_Receiver, Comment, CommentDate) VALUES (@commentSender, @commentReceiver, @comment, @commentDate)", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@commentSender", Label1.Text);
                    cmd.Parameters.AddWithValue("@commentReceiver", txtFriend.Text);
                    cmd.Parameters.AddWithValue("@comment", txtFriendComment.Text);
                    cmd.Parameters.AddWithValue("@commentDate", DateTime.Now.ToString());
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    Response.Redirect("WebForm3.aspx");
                    con.Close();


                }

            }

            


        }

        catch (Exception ex)
        {
            Response.Write(ex);
        }

    }




    protected void btnexit_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    protected void btnhome_Click(object sender, EventArgs e)
    {
        Response.Redirect("webform4.aspx");
    }
}