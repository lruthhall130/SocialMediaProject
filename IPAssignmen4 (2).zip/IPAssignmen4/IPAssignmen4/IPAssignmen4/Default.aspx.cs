﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Reflection;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnect"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {

        using (SqlConnection con = new SqlConnection("Data Source=etc"))
        {
           
        }
        con.Open();

    }

    protected void defaultButton_Click(object sender, EventArgs e)
    {

        
        bool exists = false;

        // create a command to check if the username exists
        using (SqlCommand cmd = new SqlCommand("select count(*) from [User] where User_Username = @user", con))
        {

            cmd.Parameters.AddWithValue("@user", usernametxt.Text);
            exists = (int)cmd.ExecuteScalar() > 0;
        }

        // if exists, show a message error
        if (exists)
        {
            userError.Text = "This username has been using by another user.";
            userError.Visible = true;
            con.Close();
        }

        else
        {
            Session["Email"] = mailtxt.Text;
            Session["UserName"] = usernametxt.Text;

            Response.Redirect("Webform2.aspx");

        }


            
    }

   

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("adminlogin.aspx");
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("adminlogin.aspx");
    }
}