﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebForm3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
            

    }

   protected void lbInsert_Click(object sender, EventArgs e)
    {
        SqlDataSource1.InsertParameters["User_Username"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtName")).Text;
        SqlDataSource1.InsertParameters["User_Password"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtPassword")).Text;
        SqlDataSource1.InsertParameters["User_Email"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtEmail")).Text;
        SqlDataSource1.InsertParameters["User_FName"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtFName")).Text;
        SqlDataSource1.InsertParameters["User_LName"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtLName")).Text;
        SqlDataSource1.InsertParameters["User_Country"].DefaultValue = ((DropDownList)GridView1.FooterRow.FindControl("ddlCountry")).SelectedValue;

        SqlDataSource1.Insert();
    }


    protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}