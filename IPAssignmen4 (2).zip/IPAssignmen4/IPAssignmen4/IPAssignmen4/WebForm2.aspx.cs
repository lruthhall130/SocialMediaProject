﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class WebForm2 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnect"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {
        string email = (string) Session["Email"];
        string username = (string) Session["UserName"];
        con.Open();

        Label1.Text = username;
        Label2.Text = email;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            
            
            string insert = "insert into [User] (User_Username, User_Password, User_Email, User_FName, User_LName, User_Country) values (@user, @password, @email, @fname, @lname, @country)";
            SqlCommand cmd = new SqlCommand(insert, con);
            cmd.Parameters.AddWithValue("@user", Label1.Text);
            cmd.Parameters.AddWithValue("@password", password.Text);
            cmd.Parameters.AddWithValue("@email", Label2.Text);
            cmd.Parameters.AddWithValue("@fname", fName.Text);
            cmd.Parameters.AddWithValue("@lname", lName.Text);
            cmd.Parameters.AddWithValue("@country", ddlCountry.SelectedValue);
            cmd.ExecuteNonQuery();
            Response.Redirect("webform4.aspx");
            con.Close();
        }
        catch(Exception ex)
        {
            Response.Write(ex);
        }

       

    }
}
