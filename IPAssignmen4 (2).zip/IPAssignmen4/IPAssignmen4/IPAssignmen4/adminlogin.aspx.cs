﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Reflection;


public partial class adminlogin : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnect"].ConnectionString);
    string adminuser;
    string adminpass;

    protected void Page_Load(object sender, EventArgs e)
    {
       
        using (SqlConnection con = new SqlConnection("Data Source=etc"))
        {

        }
        con.Open();

        SqlCommand comm = new SqlCommand();
        comm.Connection = con;
        adminuser = string.Format(@"select Admin_Username from Admin where Admin_Username = 'admin001'");
        adminpass = string.Format(@"select Admin_Password from Admin where Admin_Password = 'Admin*3351'");

    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        if (txtAdminUserName.Text == "admin001" && txtAdminPassword.Text == "Admin*3351")
        {
            Response.Redirect("WebForm3.aspx");
            con.Close();
        }

        else
        {
            adminError.Text = "This username or password is incorrect.";
            adminError.Visible = true;
        }
    }
}